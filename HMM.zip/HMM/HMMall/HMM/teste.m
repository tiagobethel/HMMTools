clear all; close all; clc;

%trans = [0.95,0.05;
 %     0.10,0.90];
%emis = [1/6, 1/6, 1/6, 1/6, 1/6, 1/6;
 %  1/10, 1/10, 1/10, 1/10, 1/10, 1/2];

%seq1 = hmmgenerate(100,trans,emis);
%seq2 = hmmgenerate(200,trans,emis);
%seqs = {seq1,seq2};
%[estTR,estE] = hmmtrain(seqs,trans,emis);


%% Gerar uma sequ�ncia de teste
seq = 100;
filename = 'numbers.mat';
dataSet = matfile(filename);
data = dataSet.X;
trans = [.9 .1; .05 .95];

emis = [1/6, 1/6, 1/6, 1/6, 1/6, 1/6; ...
7/12, 1/12, 1/12, 1/12, 1/12, 1/12];

%% Para gerar uma sequ�ncia aleat�ria de estados e emiss�es do modelo
[seqs, estados] = hmmgenerate(seq,trans,emis);
%[estTR,estE] = hmmtrain(seqs,trans,emis);

%% Estimando a Seq��ncia do Estado
%likelystates = hmmviterbi(seq, TRANS, EMIS);
%sum(estados==likelystates)/100
