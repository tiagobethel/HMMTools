clear all; close all; clc;
Q = 2; % n�mero de estados (ensolarado e chuvoso);
O = 3; % n�mero de observa��es discretas (Caminhar, fazer compras e limpar a casa)

%% Cria��o das matrizes
% probabilidade anteior
prior = normalise(rand(1,Q));
% estados de transi��o da matriz (1: ensolarado, 2: chuvoso, 3: nublado)
trans = [0.7 0.3; 0.6 0.4];
% observa��es da matriz de emiss�o (1: com guarda-chuva, 2: sem
% guarda-chuva)
emis = [0.1 0.4 0.5; 0.4 0.5 0.1];

%% Treinamento dos dados
seq = 20; % 20 sequencias
T = 10;   % Tamanho da sequencia (per�odo de tempo. Ex: 10 dias observados)
[seqs, states] = dhmm_sample(prior, trans, emis, seq, T);

%% Avalia��o do log de probabilidade da sequ�ncia
dhmm_logprob(seqs(5,:),prior,trans,emis)
dhmm_logprob_path(prior,trans,emis,states(5,:))

%% Algoritmo Viterbi
[path] = viterbi_path(prior, trans, multinomial_prob(seqs(5,:),emis))
res = sum(path==states(5,:))/10

%% Inicializando um modelo aleatoriamente
prior_hat = normalise(rand(1,Q));
trans_hat = mk_stochastic(rand(Q,Q));
emis_hat = mk_stochastic(rand(Q,O));  

%% Aprendizado dos dados, realizando muitas itera��es de EM
[LL,prior_hat,trans_hat,emis_hat] = dhmm_em(seqs, prior_hat,trans_hat,emis_hat, 'max_iter',30);

%% plot da curva de aprendizagem
plot(LL), xlabel('Itera��es'), ylabel('Log de probabilidade'), grid on